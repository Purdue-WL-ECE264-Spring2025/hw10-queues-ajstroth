#include "queue.h"

#include "tile_game.h"


#include <stdlib.h>


//added here for easier reference

/*struct queue {

    struct linked_list data;

  };*/

  //helper function to check if two tile layour are equal
bool sameLayout(struct game_state *a, struct game_state *b)
{
    //loops trough layout to see if the layouts are the smae
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            if (a->tiles[i][j] != b->tiles[i][j])
            {
                return false;
            }
        }
    }
    return true;
}

//serialate the layout helper function
//prevents serialize being called a tons and causing timeout
uint64_t serializeLayout(struct game_state state)
{
    //creates copu of num_steps
    uint64_t stepsCopy = state.num_steps;
    //temp set num_steps to 0
    //dosnt show hpw many steps have been taken
    state.num_steps = 0;
    //serilize the modified state with num_steps =0
    uint64_t result = serialize(state);
    //resotre orginal num_steps value
    state.num_steps = stepsCopy;
    //return serialzed layout
    return result;
}

void enqueue(struct queue *q, struct game_state state) 

{

    //inset at tail or head can use either

    //use serialize found in tile_game to transfrom into a integer

    insert_at_tail(&q->data, (size_t)serialize(state));

}


struct game_state dequeue(struct queue *q) 

{ 

    //reomve tail or head use the one that is contrery to enqueue

    //thus will reomve head

    size_t remove = remove_from_head(&q->data);

    return deserialize(remove);

}


//find the minum number of moves to solve

int number_of_moves(struct game_state start) 

{

    //want to follow this structr BFS

    /*

    node bfs(graph g, node start, node search)

    {

        queue q = new_queue();

        while (!empty(s))

        {

            node cur = dequeue(&q);

            if (equals(cur, search))

            {

                return cur;

            } else {

                for (node child in children(cur))

                {

                    enqueue(&q, child);

                }

            }

        }

    }

    */

    //start with an empty queue

    //iniitalize queue

    //queue q = new_queue();

    struct queue q = {0};

    //set the head of q to be null

    q.data.head = NULL;

    //inialize a linked list to keep track of what has already been seen

    struct linked_list seenStates = {0};


    //enqueue(&q, child);

    //add starting tile to queue

    enqueue(&q, start);
    
    //add serialed layour of the starting state to the seen list
    insert_at_tail(&seenStates, serializeLayout(start));


    //while (!empty(s))

    //BfS loop

    while (q.data.head)

    {

        //node cur = dequeue(&q);

        //dequeue the tile to get the next tile

        struct game_state cur = dequeue(&q);

        //have to determine if the tile puzzle is solved

        //assume that the puzzle is solved

        bool solved = true;

        //expected value starts at 1

        int value = 1;


        //GOAL

        //1 2 3 4 

        //5 6 7 8

        //9 10 11 12

        //13 14 15 0



        //go through tile puzzle

        for (int i = 0; i < 4 && solved; i++)

        {

            for (int j = 0; j < 4 && solved; j++)

            {

                if (i == 3 && j == 3)

                {

                    //the bottom right corrent should be 0 and empty

                    if (cur.tiles[i][j] != 0)

                    {

                        //if it not zero then it is not solved

                        solved = false;

                    }

                }

                else

                {

                    //the other tiles should be in the correct order

                    if (cur.tiles[i][j] != value)

                    {

                        solved = false;

                    }

                    //if value is correct than move on

                    value++;

                }

            }

        }

        

        //if the tile puzzle haas been solved

        if (solved)

        {

            //free memory

            free_list(seenStates);

            //use free_list to free q.data

            free_list(q.data);

            //retunr the numver of moves made to get to solved

            return cur.num_steps;

        }



        //moves in 4 direction
        //4 possible moves to be made
        //easier to do this so it can be looped through
        void (* moves[4])(struct game_state *) = {
            move_up, move_down, move_left, move_right
        };

        //attempt to move each direction

        for (int k = 0; k < 4; k++)

        {
            //copy the current state to change
            struct game_state nextCur = cur;
            //appy the move to the copied state
            moves[k](&nextCur);

            //if the move was invalid move on
            if (nextCur.empty_row == cur.empty_row && nextCur.empty_col == cur.empty_col)
            {
                continue;
            }

            //serialize the layour of the new state
            uint64_t layout = serializeLayout(nextCur);


            //check to see if the file has already been seen

            bool completeAlready = false;

            //start the loop with a pointer node intialzed to the head of seenstates
            //contintue to loop will node is not NULL
            //move tot ht next node
            for (struct list_node *node = seenStates.head; node != NULL; node = node->next)
            {
                //if the current nodes value matches the laupur
                if (node->value == layout)
                {
                    //if the match is found it means that the layour has already been seen
                    completeAlready = true;
                    //end loop
                    break;
                }
            }

            //if the syaye has already been seen move on
            if (completeAlready)
            {
                continue;
            }


            //add the new layout to the list of seen states
            insert_at_tail(&seenStates, layout);

            //add to BFS queue

            //enqueue(&q, child);

            enqueue(&q, nextCur);

        }

    }

    

    //if no solution is found

    //free memory

    free_list(seenStates);

    //use free_list to free q.data memory

    free_list(q.data);


    //return -1 to insicate that the tile puzzle cannot be solved

    return -1;

    //return 0;

}
